//
//  AppDelegate.h
//  hotfix-ios-demo
//
//  Created by junmo on 2017/10/19.
//  Copyright © 2017年 junmo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

