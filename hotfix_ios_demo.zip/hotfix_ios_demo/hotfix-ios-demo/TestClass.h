//
//  TestClass.h
//  AlicloudHotFixTestApp
//
//  Created by junmo on 2017/9/18.
//  Copyright © 2017年 junmo. All rights reserved.
//

#ifndef TestClass_h
#define TestClass_h

@interface TestClass : NSObject

- (NSString *)output;

@end

#endif /* TestClass_h */
